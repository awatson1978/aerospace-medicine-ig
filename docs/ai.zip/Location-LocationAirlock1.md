# Location - Airlock1 - v0.5.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Airlock1**

## Example Location: Location - Airlock1

**name**: Location - Airlock1



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationAirlock1",
  "name" : "Location - Airlock1"
}

```
