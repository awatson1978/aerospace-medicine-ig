# Org - Department of Commerce - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Org - Department of Commerce**

## Example Organization: Org - Department of Commerce

**name**: Department of Commerce



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "UsDepartmentOfCommerce",
  "name" : "Department of Commerce"
}

```
