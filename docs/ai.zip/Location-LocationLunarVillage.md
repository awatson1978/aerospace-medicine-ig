# Location - Lunar Village - v0.5.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Lunar Village**

## Example Location: Location - Lunar Village

Profile: [xGeo Locations](StructureDefinition-SpaceLocation.md)

**name**: Location - Lunar Village



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationLunarVillage",
  "meta" : {
    "profile" : [
      "https://mitre.org/fhir/space-health/StructureDefinition/SpaceLocation"
    ]
  },
  "name" : "Location - Lunar Village"
}

```
