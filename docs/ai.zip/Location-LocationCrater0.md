# Location - Crater - v0.5.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Crater**

## Example Location: Location - Crater

**name**: Location - Crater



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationCrater0",
  "name" : "Location - Crater"
}

```
