# Location - Soyez Capsule - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Soyez Capsule**

## Example Location: Location - Soyez Capsule

**name**: Location - Soyez Capsule



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationSoyez",
  "name" : "Location - Soyez Capsule"
}

```
