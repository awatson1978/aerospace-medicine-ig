# Org - NASA - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Org - NASA**

## Example Organization: Org - NASA

**name**: NASA



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "NASA",
  "name" : "NASA"
}

```
