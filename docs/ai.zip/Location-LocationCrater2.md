# Location - Telescope Crater - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Telescope Crater**

## Example Location: Location - Telescope Crater

**name**: Location - Telescope Crater



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationCrater2",
  "name" : "Location - Telescope Crater"
}

```
