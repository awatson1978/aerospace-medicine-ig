# Org - Axiom Space - v0.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Org - Axiom Space**

## Example Organization: Org - Axiom Space

**name**: Axiom Space



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "AxiomSpace",
  "name" : "Axiom Space"
}

```
