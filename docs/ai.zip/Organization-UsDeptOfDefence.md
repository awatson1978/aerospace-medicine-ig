# Department of Defense - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Department of Defense**

## Example Organization: Department of Defense

**name**: ment of Defense



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "UsDeptOfDefence",
  "name" : "ment of Defense"
}

```
