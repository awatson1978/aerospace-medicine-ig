# Location - Palace in the Sky - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Palace in the Sky**

## Example Location: Location - Palace in the Sky

Profile: [xGeo Locations](StructureDefinition-SpaceLocation.md)

**name**: Location - Palace in the Sky



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationTaingong",
  "meta" : {
    "profile" : [
      "https://mitre.org/fhir/space-health/StructureDefinition/SpaceLocation"
    ]
  },
  "name" : "Location - Palace in the Sky"
}

```
