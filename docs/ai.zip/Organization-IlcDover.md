# Org - ILC Dover - v0.5.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Org - ILC Dover**

## Example Organization: Org - ILC Dover

**name**: ILC Dover



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "IlcDover",
  "name" : "ILC Dover"
}

```
