# Blue Origin West Texas Facility - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Blue Origin West Texas Facility**

## Example Location: Blue Origin West Texas Facility

**name**: Blue Origin West Texas

**description**: New Shepard suborbital tourist flights and crew training

**address**: Van Horn TX US 



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "BlueOriginWestTexas",
  "name" : "Blue Origin West Texas",
  "description" : "New Shepard suborbital tourist flights and crew training",
  "address" : {
    "city" : "Van Horn",
    "state" : "TX",
    "country" : "US"
  }
}

```
