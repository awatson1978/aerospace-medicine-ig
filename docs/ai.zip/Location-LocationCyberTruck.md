# Location - Cyber Truck - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Cyber Truck**

## Example Location: Location - Cyber Truck

**name**: Location - Cyber Truck



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationCyberTruck",
  "name" : "Location - Cyber Truck"
}

```
