# Location - SpaceGarage1 - v0.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - SpaceGarage1**

## Example Location: Location - SpaceGarage1

**name**: Location - SpaceGarage1



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationSpaceGarage",
  "name" : "Location - SpaceGarage1"
}

```
