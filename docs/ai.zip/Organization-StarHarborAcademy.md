# Org - Star Harbor Academy - v0.5.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Org - Star Harbor Academy**

## Example Organization: Org - Star Harbor Academy

**name**: Star Harbor Academy



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "StarHarborAcademy",
  "name" : "Star Harbor Academy"
}

```
