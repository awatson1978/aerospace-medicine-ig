# Location - Lunar Tent 1 - v0.5.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Lunar Tent 1**

## Example Location: Location - Lunar Tent 1

**name**: Location - Lunar Tent 1



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationLunarTent1",
  "name" : "Location - Lunar Tent 1"
}

```
