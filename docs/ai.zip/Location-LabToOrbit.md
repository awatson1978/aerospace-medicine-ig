# Location - Lab To Orbit - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Lab To Orbit**

## Example Location: Location - Lab To Orbit

Profile: [xGeo Locations](StructureDefinition-SpaceLocation.md)

**name**: Location - Lab To Orbit



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LabToOrbit",
  "meta" : {
    "profile" : [
      "https://mitre.org/fhir/space-health/StructureDefinition/SpaceLocation"
    ]
  },
  "name" : "Location - Lab To Orbit"
}

```
