# Mission Phase Code System - Aerospace Medicine Implementation Guide v0.7.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mission Phase Code System**

## CodeSystem: Mission Phase Code System (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://awatson1978.github.io/aerospace-medicine-ig/CodeSystem/mission-phase-cs | *Version*:0.7.0 |
| Active as of 2026-09-02 | *Computable Name*:MissionPhaseCS |
| **Copyright/Legal**: Copyright 2022-2026 The MITRE Corporation and Abigail Watson. Licensed under Creative Commons Attribution-NoDerivatives 4.0 International (CC BY-ND 4.0). Approved for Public Release; Distribution Unlimited. Public Release Case Number 25-1124. | |

 
Phases of a space mission for temporal context of clinical observations 

 This Code system is referenced in the content logical definition of the following value sets: 

* [MissionPhaseVS](ValueSet-mission-phase-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mission-phase-cs",
  "url" : "https://awatson1978.github.io/aerospace-medicine-ig/CodeSystem/mission-phase-cs",
  "version" : "0.7.0",
  "name" : "MissionPhaseCS",
  "title" : "Mission Phase Code System",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-09-02T13:24:45-05:00",
  "publisher" : "MITRE",
  "contact" : [
    {
      "name" : "MITRE",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.mitre.org/"
        }
      ]
    }
  ],
  "description" : "Phases of a space mission for temporal context of clinical observations",
  "copyright" : "Copyright 2022-2026 The MITRE Corporation and Abigail Watson. Licensed under Creative Commons Attribution-NoDerivatives 4.0 International (CC BY-ND 4.0). Approved for Public Release; Distribution Unlimited. Public Release Case Number 25-1124.",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 10,
  "concept" : [
    {
      "code" : "pre-flight",
      "display" : "Pre-flight",
      "definition" : "Period before launch including training and medical baseline"
    },
    {
      "code" : "launch-ascent",
      "display" : "Launch and Ascent",
      "definition" : "From liftoff through orbital insertion or trans-lunar injection"
    },
    {
      "code" : "transit-outbound",
      "display" : "Outbound Transit",
      "definition" : "Transit from Earth orbit to destination (Moon, Mars, etc.)"
    },
    {
      "code" : "orbital-ops",
      "display" : "Orbital Operations",
      "definition" : "Operations while in orbit around Earth or another body"
    },
    {
      "code" : "lunar-surface-ops",
      "display" : "Lunar Surface Operations",
      "definition" : "Operations on the lunar surface including EVAs"
    },
    {
      "code" : "mars-surface-ops",
      "display" : "Mars Surface Operations",
      "definition" : "Operations on the Mars surface"
    },
    {
      "code" : "transit-return",
      "display" : "Return Transit",
      "definition" : "Transit from destination back toward Earth"
    },
    {
      "code" : "entry-descent",
      "display" : "Entry and Descent",
      "definition" : "Atmospheric re-entry and landing"
    },
    {
      "code" : "post-flight-acute",
      "display" : "Post-flight Acute",
      "definition" : "Immediate post-landing period, typically R+0 to R+3 days"
    },
    {
      "code" : "post-flight-reconditioning",
      "display" : "Post-flight Reconditioning",
      "definition" : "Extended reconditioning period, typically R+3 days to R+45 days"
    }
  ]
}

```
