# Mars Direct - v0.6.0

* [**Table of Contents**](toc.md)
* **Mars Direct**

## Mars Direct

## Mars Direct Mission Architecture

### Overview

On November 16, 1990, Robert Zubrin unveiled **Mars Direct** at the Case for Mars conferencea plan so audacious yet elegant that it reshaped how humanity thought about reaching the Red Planet. Unlike NASA's 1989 Space Exploration Initiative (requiring 30 launches and $450 billion), Mars Direct proposed just **two heavy-lift launches per mission**, leveraging **in-situ resource utilization (ISRU)** to produce propellant on Mars itself.

The concept: Send an Earth Return Vehicle (ERV) first, equipped with a small nuclear reactor and chemical plant. Over 10 months, this automated system harvests CO₂ from Mars' atmosphere, combines it with hydrogen brought from Earth via the Sabatier reaction, and produces 112 tons of methane/oxygen propellant. Only after fuel production is confirmed does a second launch deliver four crew members in a Mars Habitat Unit. They spend **18 months on Mars**a long-stay conjunction-class mission maximizing surface scienceconducting EVAs, living in the habitat, then returning in the fueled ERV.

Mars Direct's elegance lay in **leveraging proven 1990s technology**: chemical rockets, nuclear power, cryogenic storage, robust life supportavoiding risky orbital rendezvous and on-orbit assembly. For transit, Zubrin proposed a tether to a spent stage, spinning to generate 1g artificial gravity, mitigating bone loss and muscle atrophy. A storm shelter surrounded by water/provisions would protect crew during solar particle events.

**The legacy lives on.** NASA's 1993 Design Reference Mission (DRM 1.0) explicitly adapted Mars Direct into "Mars Semi-Direct," keeping split missions and ISRU but adding Mars Orbit Rendezvous. NASA's Design Reference Architecture 5.0 (DRA 5.0, 2009) envisions nuclear thermal rockets, fission surface power (~25 kW for ISRU), and multiple heavy launches per missionmore complex but building on Mars Direct's ISRU foundation. SpaceX's Starship Mars Plan represents a modern private-sector embodiment: fully reusable rockets, orbital refueling (10-14 tanker flights per Mars-bound Starship), direct Earth→Mars trajectories, and massive ISRU (hundreds of tons CH₄/O₂, requiring ~600 kW power). Project Athena (2025), championed by Jared Isaacman, proposes accelerating Mars efforts with uncrewed infrastructure missions by 2026, nuclear-electric propulsion development, and NASA-commercial partnerships.

But **rockets are only half the story.** A Mars mission is a **biomedical crucible**: ~2.5 years in the most hostile environment humans have attemptedsix months microgravity transit each way, 18 months on Mars in 0.38g, communication delays of 5-20 minutes rendering real-time ground support impossible, cumulative radiation exposure ~600-1000 mSv (approaching NASA career limits), Martian dust exposure (perchlorates, lung irritation risk), autonomous medical operations with no evacuation option. Every heartbeat, every milligram of calcium lost, every millisievert absorbed, every moment of psychological strain must be tracked, analyzed, mitigated.

### Mission Architecture Comparison

| | | | |
| :--- | :--- | :--- | :--- |
| **Mars Direct (1990)** | 2 launches (ERV + Hab); ISRU CH₄/O₂; 18-month surface stay; artificial gravity tether; 4 crew | Baseline |  |
| **NASA DRA 5.0 (2009)** | 4-5 launches; Mars orbit rendezvous; crew of 6; nuclear thermal rockets; fission surface power; 2030s timeline | ISRU (O₂ via MOXIE tested on Perseverance); long surface stays; pre-deploy cargo | More infrastructure; slower timeline; Gateway staging vs. direct transit |
| **SpaceX Starship (2016)** | Fully reusable 100t vehicle; orbital refueling (10-14 tankers); land entire Starship; ISRU for return; ~2029-2031 target | ISRU CH₄/O₂; direct flights; bold schedule | Orbital refueling required; 200-ton lander (new challenges); no artificial gravity; commercial funding |
| **Project Athena (2025)** | Uncrewed demo by 2026; nuclear-electric propulsion; NASA-commercial partnership; post-Artemis pivot to Mars | Leverages SpaceX heavy lift; ISRU & nuclear power priority | Far faster timeline; NEP technology push; NASA reorganization proposal |

### Aerospace Medicine Challenges

#### The 2.5-Year Gauntlet

**Outbound Transit (6 months, microgravity)**: Bone loss ~1-2%/month, muscle atrophy, cardiovascular deconditioning, fluid shift → SANS (vision changes), immune dysregulation, circadian disruption

**Mars Surface (18 months, 0.38g)**: Partial gravity insufficient to prevent bone/muscle loss (unknown long-term effects); Martian dust (perchlorates, silica-like particles → respiratory irritation, equipment degradation); thermal extremes (-173°C to +127°C); EVA workloads; habitat confinement; psychological isolation

**Return Transit (6 months, microgravity)**: Cumulative bone loss ~12-24 months total; radiation approaching career limits; crew fatigue; aging equipment

**Total radiation**: ~600-1000 mSv over 2.5 years vs. ISS ~50-200 mSv/year. Beyond Earth's magnetosphere, continuous **galactic cosmic rays (GCR)**high-energy protons, heavy ions from distant supernovaeplus unpredictable **solar particle events (SPEs)** that can deliver lethal doses in hours without shielding. Lifetime cancer risk increase ~3-5%.

#### Mars Surface Operations

**Martian dust**: Jagged, electrostatically charged, ~0.5% perchlorates (ClO₄⁻) toxic oxidizing compounds. Clings to suits, infiltrates habitats. Inhalation → lung irritation (analogous to silicosis), potential bloodstream entry. Equipment degradation (seal wear, optics scratching). EVA decontamination protocols mission-critical.

**EVAs**: Unlike zero-G spacewalks, Mars EVAs involve walking/climbing in 0.38g, suits at ~4 psi O₂ (pre-breathe to avoid decompression sickness). Hundreds of EVAs over 500 sols → repetitive orthopedic strain (shoulder injuries common on ISS), chronic fatigue, cumulative dust exposure. Biomedical telemetry: heart rate, suit pressure, O₂, thermal regulation.

**Habitat life support**: 21% O₂, ~8-14.7 psi pressure, temperature/humidity control. O₂ generation (water electrolysis), CO₂ scrubbing (solid amine/Sabatier), trace contaminant removal, dust monitoring. Power (solar, batteries, possibly Kilopower fission reactor) sustains life supportfailure —rapid CO₂ buildup or hypoxia. Water recycling (urine→potable, humidity recovery) closed-loop with minimal resupply.

#### Autonomous Medical Operations

**5-20 minute communication delays** → crew must diagnose/treat themselves. Crew Medical Officer (CMO) leads, all trained in basic trauma response. Medical kit: portable ultrasound, handheld lab analyzers, vital signs monitors, medications (antibiotics, analgesics, sedatives), surgical instruments, defibrillator, airway management, limited blood products.

**Worst-case scenarios**: appendicitis requiring surgery in 0.38g without sterile OR/anesthesiologist; kidney stones (elevated risk from bone calcium loss); traumatic injury; acute radiation sickness from solar storm. NASA developing AI-driven diagnostic aids, structured digital checklists.

**FHIR perspective**: Offline clinical data capture, asynchronous transmission. Every diagnosis, procedure, medication, vital logged locally, downlinked when bandwidth permits. Structured resources (Observation, Procedure, Condition, MedicationAdministration) enable flight surgeons to reconstruct events days later.

#### In-Situ Resource Utilization (ISRU)

**Mission-critical**: Propellant production failure strands crew. Sabatier reaction: CO₂ + 4H₂ → CH₄ + 2H₂O; electrolysis: 2H₂O → 2H₂ + O₂. Mars Direct ERV: ~8 tons H₂ → 112 tons propellant. SpaceX Starship: ~600 tons needed, demanding ~600 kW continuous power (solar arrays >38,000 m²).

**Health implications**: Handling cryogenic CH₄/O₂, high-pressure H₂ (explosive risk); ISRU failure → existential mission risk, severe crew psychological stress; byproduct contamination (CO leaks) → air quality monitoring.

**FHIR modeling**: ISRUProductionLog Observations tracking output, reactor status, alarms. Not directly medical, but ISRU status feeds risk assessments and crew stress monitoring.

### FHIR Implementation Architecture

#### Core Concepts

* **Mission Duration**: 2.5 years vs. 6-month ISS rotations —longitudinal health tracking, career dose limits, cumulative bone loss trends
* **Communication Latency**: 5-20 min delays —asynchronous data exchange, offline decision support, batch transmission
* **Autonomous Medicine**: Crew-led diagnosis/treatment —structured protocols, decision trees, comprehensive local FHIR repositories
* **Mars Environment**: 0.38g, dust, thermal/radiation extremes —new Observation profiles
* **ISRU Dependency**: Production success tied to mission viability and crew psychology —ISRU status as operational health indicator

#### Data Architecture

* **Mission Timeline**: Launch, outbound transit (6 mo), orbit insertion, descent, surface ops (18 mo, hundreds of EVAs), ascent, return transit (6 mo), re-entry
* **Radiation Dosimetry**: Real-time dose rates, cumulative GCR, SPE tracking, tissue-specific doses, career limits
* **Environmental Monitoring**: Cabin pressure, O₂/CO₂, temperature, dust, ISRU status
* **Physiologic Data**: Daily vitals, weekly bone density, cardiovascular, cognitive tests (PVT), behavioral surveys (PHQ-9, GAD-7)
* **Operational Events**: EVA schedules, transfers, ISRU milestones, malfunctions, interventions
* **Location Context**: Mars landing sites (areographic coordinates), habitat modules, rover excursions

All link to **MissionContext** extensions and **Mars Mission** CodeSystem entries.

#### Standardized Terminologies

New code systems and value sets:

* **[MarsMissionsCS](CodeSystem-mars-missions-cs.md)**: Robotic missions (Mariner 4, Viking, Pathfinder, Spirit, Opportunity, Curiosity, Perseverance) + future crewed
* **[MarsMissionsVS](ValueSet-mars-missions-vs.md)**: All Mars missions
* **[CrewedMarsMissionsCS](CodeSystem-crewed-mars-missions-cs.md)**: Architectures (Mars Direct, DRM 3.0, DRA 5.0, Starship, Olympus)
* **[CrewedMarsMissionsVS](ValueSet-crewed-mars-missions-vs.md)**: Human mission plans
* **[MarsLandingSitesCS](CodeSystem-mars-landing-sites-cs.md)**: Candidate sites with coordinates (Jezero, Arcadia, Gale, Elysium, Hellas, Mawrth)
* **[MarsLandingSitesVS](ValueSet-mars-landing-sites-vs.md)**: Landing site selection
* **[MarsCertifiedDevicesCS](CodeSystem-mars-devices-certified-cs.md)**: Flight-qualified hardware (Orion, Crew Dragon, ISS ECLSS, EMU, Bio-Monitor)
* **[MarsCertifiedDevicesVS](ValueSet-mars-devices-certified-vs.md)**: Certified devices
* **[MarsPrototypeDevicesCS](CodeSystem-mars-devices-prototype-cs.md)**: Developmental (Starship, Mars Habitat, xEMU, ISRU Plant, Kilopower, Rovers)
* **[MarsPrototypeDevicesVS](ValueSet-mars-devices-prototype-vs.md)**: Prototype devices
* **[MarsAllDevicesVS](ValueSet-mars-all-devices-vs.md)**: Combined devices

Integration with existing terminologies:

* **SNOMED CT**: Conditions, procedures, findingsgaps: SANS, Martian dust exposure, Mars EVA
* **LOINC**: Radiation, vitals, atmospheric compositionsome Mars metrics need new codes
* **NASA HMTA**: Exposure limits, medical event categories, crew health requirements

### Use Cases

#### 1. Mars Direct Mission Health Surveillance

4 crew, 18-month surface stay. Continuous vitals (transit), daily logs, radiation dosimetry with SPE alerts, post-EVA assessments (~200 surface EVAs), weekly bone trending, behavioral telecounseling bi-weekly. First humans >600 mSv cumulativelong-term cancer risk tracking essential.

#### 2. SpaceX Starship Surface Operations

6-12 crew, 6-month stay (next return window). ISRU monitoring (600 tons O₂/CH₄ production), habitat environmental control (larger crew —higher CO₂), EVA deploying solar arrays, autonomous medical for larger crew (higher medical event probability), psychological dynamics in Starship interior.

#### 3. Solar Storm Radiation Management

Dosimetry detects sudden spike (SPE begins). Automated alert —crew to storm shelter (water-walled). Continuous monitoring 24-48 hr SPE, cumulative dose vs. acute thresholds, post-event assessment (nausea, fatigue, lymphocyte drop), cancer risk recalculation, mission continuation evaluation.

#### 4. Autonomous Emergency Surgery: Appendicitis

Crew develops RLQ pain, fever, elevated WBC. Ultrasound confirms appendicitis. 12-min one-way delay. CMO consults digital protocol, ground sends guidance (24-min round trip). Crew administers anesthesia (ketamine), performs appendectomy in 0.38g, post-op antibiotics. Encounter captures: pre-op vitals/imaging, Procedure (steps), Medications, post-op wound healing, Condition resolved.

#### 5. ISRU Failure and Crew Stress

Sabatier reactor fault Sol 180, CH₄ production drops 40%. Repairs take 3 weeks. Anxiety spikes (GAD-7 increases), sleep deteriorates (wearable sensors show reduced REM), interpersonal tension. RiskAssessment updated: if not restored, one-way or rescue (neither realisticimmense psychological burden). Reactor repaired Sol 201. Post-crisis behavioral interventions. Data shows ISRU as critical psychological stressor.

#### 6. Long-Duration Bone Loss Fracture

18 months surface stay (~24 mo equivalent microgravity + partial gravity). Crew falls during EVA, severe ankle pain. Ultrasound suggests fracture, confirmed imaging. Closed reduction, splinting, pain management, non-weight-bearing 6-8 weeks (challenge in 0.38g). Healing monitored. Condition links fracture to bone demineralization (prior DEXA: 15% loss). Informs future countermeasure protocols.

### Data Model Architecture

#### Core FHIR Resources

* **Observation** —Radiation, environmental, vitals, cognitive, biomarkers, bone density, blood chemistry
* **Procedure** —MarsEVAProcedure, transfers, interventions, ISRU maintenance
* **Condition** —Space adaptation syndrome, SANS, radiation effects, DCS, dust pneumoconiosis, fractures
* **Device** —Orion, Starship, habitats, xEMU, rovers, dosimeters, medical equipment, ISRU plant
* **Location** —Landing sites (areographic coordinates), habitat compartments, storm shelter
* **Encounter** —Mission phases (launch, transit, orbit, descent, surface ops, ascent, return, re-entry)
* **PlanDefinition** —Mission timelines, EVA schedules, medical protocols, countermeasures
* **RiskAssessment** —Radiation (cancer, CNS), bone fracture, behavioral vulnerability, ISRU failure impact
* **MedicationAdministration** —All meds (antibiotics, analgesics, sedatives, radiation countermeasures, bone protective)
* **CarePlan** —Individual health plans (exercise, nutrition, radiation limits, behavioral support)

#### Extensions

* **missionContext** —Links to specific Mars mission and phase
* **areographicCoordinates** —Mars lat/long for Locations
* **isruStatus** —Links to ISRU production status
* **evaNumber** —Sequential EVA identifier
* **communicationDelay** —Time lag for transmissions

#### Profiles

* **MarsEVAProcedure**: Surface EVAsduration, location, participants, suit, metabolic data, dust exposure, post-EVA health check
* **HabitatEnvironmentalObservation**: Atmospheric monitoringO₂%, CO₂, pressure, temp, humidity, dust; subject = habitat Location
* **ISRUProductionLog**: ISRU outputpropellant mass (kg CH₄, O₂), reactor status, power; links to Device (ISRU plant)
* **MarsCrewMemberProfile**: Patientradiation career dose, flight certification, bone baseline, resilience score
* **MissionTimelinePlan**: PlanDefinitionphases (launch, transit, ops, return), medical protocols, EVA schedules
* **MarsRadiationRiskAssessment**: Long-duration exposurebasis = cumulative dose; prediction = cancer/CNS risk
* **AutonomousMedicalEncounter**: Crew-led eventsno real-time ground support; groups Obs/Procs/Conds/Meds; communication delay context

### Integration and Future Directions

**Integration**: Mars data —NASA LSAH database (longitudinal tracking); terrestrial EHR handoff; real-time (delayed) dashboards for Mission Control; environmental alerts trigger operational responses; career dose enforces exposure limits

**Future**: Interplanetary standardization (asteroid, Jupiter/Saturn moons); AI-driven autonomous medicine (digital twins, predictive models); closed-loop life support + medical ISRU (3D-printed pharmaceuticals, regenerative medicine); Mars permanent settlement medicine (obstetrics, pediatrics, colonial healthcare)

-------

**Mars Direct was never just about rocketsit was about believing humans could adapt and thrive in the most alien environment imaginable.** The FHIR architectures in this Implementation Guide ensure every breath, heartbeat, millisievert, and moment of courage on Mars will be captured, preserved, and transformed into knowledge guiding future crews until Mars becomes humanity's second home.

### References

#### Mars Direct Mission Architecture

* [Mars Direct: A Simple, Robust, and Cost Effective Architecture (Zubrin 1991 AIAA Paper)](https://marspapers.org/paper/Zubrin_1991.pdf)
* [The Case for Mars - Wikipedia](https://en.wikipedia.org/wiki/The_Case_for_Mars)
* [Mars Direct - The Mars Society](https://www.marssociety.org/concepts/mars-direct/)
* [Mars Society Founder Makes Case for 'Mars Direct' Path to the Red Planet](https://www.space.com/crewed-mars-direct-missions-robert-zubrin-iac-2019.html)

#### NASA Design Reference Architectures

* [Human Exploration of Mars Design Reference Architecture 5.0 (NASA SP-2009-566)](https://www.nasa.gov/wp-content/uploads/2015/09/373665main_nasa-sp-2009-566.pdf)
* [Mars Design Reference Mission - Wikipedia](https://en.wikipedia.org/wiki/Mars_Design_Reference_Mission)
* [Proceedings of the Symposium on Manned Planetary Mission 1963](https://ntrs.nasa.gov/api/citations/19640017065/downloads/19640017065.pdf)
* [Manned Mars Landing Presentation To The Space Task Group (von Braun)](https://newspaceeconomy.ca/wp-content/uploads/2023/08/19690804_manned_mars_landing_presentation_to_the_space_task_group_by_dr._wernher_von_braun.pdf)
* [The Post-Apollo Space Program: Directions for the Future](https://www.nasa.gov/history/the-post-apollo-space-program-directions-for-the-future/)

#### SpaceX and Commercial Mars Missions

* [SpaceX Mars colonization program - Wikipedia](https://en.wikipedia.org/wiki/SpaceX_Mars_colonization_program)
* [Mission Architecture Using SpaceX Starship for Mars (New Space Journal)](https://www.liebertpub.com/doi/10.1089/space.2020.0058)
* [3 months transit time to Mars using SpaceX Starship (Scientific Reports)](https://www.nature.com/articles/s41598-025-00565-7)
* [About feasibility of SpaceX's human exploration Mars mission scenario with Starship (Scientific Reports)](https://www.nature.com/articles/s41598-024-54012-0)
* [SpaceX: To The Moon and Beyond](https://www.spacex.com/updates#moon-and-beyond)

#### ISRU and Propulsion Systems

* [Sabatier System Design Study for Mars ISRU Propellant Production (NASA)](https://ntrs.nasa.gov/api/citations/20180004697/downloads/20180004697.pdf)
* [A membrane Sabatier system for water recovery and rocket propellant production (Nature)](https://www.nature.com/articles/s41467-025-63667-w)
* [National Strategy for Space Nuclear Power and Propulsion](https://www.federalregister.gov/documents/2020/12/23/2020-28457/posting-of-the-presidential-policy-directive-6-space-policy-national-strategy-for-space-nuclear)
* [NASA tests compact nuclear reactor for Mars base](https://gizmodo.com/nasa-runs-successful-first-tests-of-compact-nuclear-rea-1822233354)
* [Kilopower passes big ground test](https://www.space.com/40479-space-nuclear-reactor-kilopower-passes-big-test.html)

#### Robotics and Surface Operations

* [Mars Relay Network - Orbital Dynamics](https://x.com/nasamars/status/1962990877128982696?s=61)
* [Cooperative robotic exploration of a planetary skylight surface and lava cave](https://www.science.org/doi/10.1126/scirobotics.adj9699)

#### NASA Research and Data

* [NASA Open Science Data Repository](https://smce.nasa.gov/open-science-data-repository-osdr/)
* [NASA OSDR-GeneLab Enabled Publications](https://scholar.google.com/citations?user=8T1QuYEAAAAJ&hl=en)

