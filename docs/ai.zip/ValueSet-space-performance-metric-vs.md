# Space Exercise Performance Metrics - v0.5.12

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Space Exercise Performance Metrics**

## ValueSet: Space Exercise Performance Metrics 

| | |
| :--- | :--- |
| *Official URL*:https://mitre.org/fhir/space-health/ValueSet/space-performance-metric-vs | *Version*:0.5.12 |
| Active as of 2026-03-25 | *Computable Name*:SpacePerformanceMetricVS |

 
Performance metrics for space exercise (defined in SpacePerformanceMetricCS) 

 **References** 

* [Space Exercise Activity Measure](StructureDefinition-space-exercise-activity-measure.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "space-performance-metric-vs",
  "url" : "https://mitre.org/fhir/space-health/ValueSet/space-performance-metric-vs",
  "version" : "0.5.12",
  "name" : "SpacePerformanceMetricVS",
  "title" : "Space Exercise Performance Metrics",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-03-25T00:24:16-05:00",
  "publisher" : "MITRE",
  "contact" : [
    {
      "name" : "MITRE",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.mitre.org/"
        }
      ]
    }
  ],
  "description" : "Performance metrics for space exercise (defined in SpacePerformanceMetricCS)",
  "compose" : {
    "include" : [
      {
        "system" : "http://hl7.org/fhir/uv/aerospace/CodeSystem/space-performance-metric-cs"
      }
    ]
  }
}

```
