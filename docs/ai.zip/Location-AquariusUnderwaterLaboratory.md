# Aquarius Underwater Laboratory - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Aquarius Underwater Laboratory**

## Example Location: Aquarius Underwater Laboratory

**name**: Aquarius Underwater Laboratory

**description**: Underwater habitat 62 feet deep off Key Largo for saturation diving training

**address**: Key Largo FL US 



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "AquariusUnderwaterLaboratory",
  "name" : "Aquarius Underwater Laboratory",
  "description" : "Underwater habitat 62 feet deep off Key Largo for saturation diving training",
  "address" : {
    "city" : "Key Largo",
    "state" : "FL",
    "country" : "US"
  }
}

```
