# Org - TRISH - v0.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Org - TRISH**

## Example Organization: Org - TRISH

**name**: TRISH



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "TRISH",
  "name" : "TRISH"
}

```
