# Space insurance - v0.5.9

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Space insurance**

## Resource Profile: Space insurance 

| | |
| :--- | :--- |
| *Official URL*:https://mitre.org/fhir/space-health/StructureDefinition/SpaceInsurance | *Version*:0.5.9 |
| Draft as of 2026-02-04 | *Computable Name*:SpaceInsurance |

 
STUB - Insurance plan for space travel 

**Usages:**

* Examples for this Profile: [InsurancePlan/SpaceTourismTravelInsurance](InsurancePlan-SpaceTourismTravelInsurance.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/mitre.fhir.spacehealth|current/StructureDefinition/SpaceInsurance)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-SpaceInsurance.csv), [Excel](StructureDefinition-SpaceInsurance.xlsx), [Schematron](StructureDefinition-SpaceInsurance.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "SpaceInsurance",
  "url" : "https://mitre.org/fhir/space-health/StructureDefinition/SpaceInsurance",
  "version" : "0.5.9",
  "name" : "SpaceInsurance",
  "title" : "Space insurance",
  "status" : "draft",
  "date" : "2026-02-04T10:26:00-06:00",
  "publisher" : "MITRE",
  "contact" : [
    {
      "name" : "MITRE",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.mitre.org/"
        }
      ]
    }
  ],
  "description" : "STUB - Insurance plan for space travel",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "InsurancePlan",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/InsurancePlan",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "InsurancePlan",
        "path" : "InsurancePlan"
      }
    ]
  }
}

```
