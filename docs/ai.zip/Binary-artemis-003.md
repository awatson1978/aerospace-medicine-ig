# Mango-peach smoothie - Aerospace Medicine Implementation Guide v0.7.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mango-peach smoothie**

## Example Binary: Mango-peach smoothie

This content is an example of the [Nutrition Product (logical model)](StructureDefinition-NutritionProduct.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "https://awatson1978.github.io/aerospace-medicine-ig/StructureDefinition/NutritionProduct",
  "id": "artemis-003",
  "meta": {
    "source": "https://awatson1978.github.io/aerospace-medicine-ig/provenance/synthetic",
    "tag": [
      {
        "code": "HTEST",
        "system": "http://terminology.hl7.org/CodeSystem/v3-ActReason",
        "display": "test health data"
      }
    ]
  },
  "status": "active",
  "code": {
    "text": "Mango-peach smoothie"
  },
  "category": [
    {
      "text": "beverage"
    }
  ],
  "instance": [
    {
      "name": "Mango-peach smoothie"
    }
  ],
  "note": [
    {
      "text": "Published Artemis II example menu item"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
