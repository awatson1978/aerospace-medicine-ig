# Spaceport America - v0.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Spaceport America**

## Example Location: Spaceport America

**name**: Spaceport America

**description**: Commercial suborbital spaceflight operations

**address**: Truth or Consequences NM US 



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "VirginGalacticSpaceport",
  "name" : "Spaceport America",
  "description" : "Commercial suborbital spaceflight operations",
  "address" : {
    "city" : "Truth or Consequences",
    "state" : "NM",
    "country" : "US"
  }
}

```
