# Location - LunarBuggy - v0.5.8

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - LunarBuggy**

## Example Location: Location - LunarBuggy

**name**: Location - LunarBuggy



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationLunarBuggy",
  "name" : "Location - LunarBuggy"
}

```
