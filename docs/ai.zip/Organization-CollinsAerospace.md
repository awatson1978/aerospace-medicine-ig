# Org - Collins Aerospace - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Org - Collins Aerospace**

## Example Organization: Org - Collins Aerospace

**name**: Collins Aerospace



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "CollinsAerospace",
  "name" : "Collins Aerospace"
}

```
