# EVS Units - v0.6.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EVS Units**

## ValueSet: EVS Units 

| | |
| :--- | :--- |
| *Official URL*:https://mitre.org/fhir/space-health/ValueSet/evs-units-vs | *Version*:0.6.2 |
| Active as of 2026-08-03 | *Computable Name*:EVSUnitsVS |

 
Units for Exercise Vital Sign measurements 

 **References** 

* [Space Exercise Vital Sign Minutes Per Week](StructureDefinition-space-evs-minutes-per-week.md)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (not supported by Publication Tooling)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "evs-units-vs",
  "url" : "https://mitre.org/fhir/space-health/ValueSet/evs-units-vs",
  "version" : "0.6.2",
  "name" : "EVSUnitsVS",
  "title" : "EVS Units",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-03T22:31:50-05:00",
  "publisher" : "MITRE",
  "contact" : [
    {
      "name" : "MITRE",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.mitre.org/"
        }
      ]
    }
  ],
  "description" : "Units for Exercise Vital Sign measurements",
  "compose" : {
    "include" : [
      {
        "system" : "http://unitsofmeasure.org",
        "concept" : [
          {
            "code" : "min/wk",
            "display" : "minutes per week"
          },
          {
            "code" : "min",
            "display" : "minutes"
          }
        ]
      }
    ]
  }
}

```
