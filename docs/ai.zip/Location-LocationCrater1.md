# Location - Ice Crater - v0.5.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Ice Crater**

## Example Location: Location - Ice Crater

**name**: Location - Ice Crater



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationCrater1",
  "name" : "Location - Ice Crater"
}

```
