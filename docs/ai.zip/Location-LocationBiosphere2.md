# Location - Biosphere2 - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Biosphere2**

## Example Location: Location - Biosphere2

**name**: Location - Biosphere2



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationBiosphere2",
  "name" : "Location - Biosphere2"
}

```
