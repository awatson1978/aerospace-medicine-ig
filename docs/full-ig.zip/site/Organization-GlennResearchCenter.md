# Org - Glenn Research Center - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Org - Glenn Research Center**

## Example Organization: Org - Glenn Research Center

**name**: Glenn Research Center



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "GlennResearchCenter",
  "name" : "Glenn Research Center"
}

```
