# Radiation Countermeasures Code System - v0.5.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Radiation Countermeasures Code System**

## CodeSystem: Radiation Countermeasures Code System 

| | |
| :--- | :--- |
| *Official URL*:https://mitre.org/fhir/space-health/CodeSystem/radiation-countermeasures-cs | *Version*:0.5.10 |
| Draft as of 2026-03-12 | *Computable Name*:RadiationCountermeasuresCS |

 
Protective measures against space radiation 

 This Code system is referenced in the content logical definition of the following value sets: 

* [RadiationCountermeasuresVS](ValueSet-radiation-countermeasures-vs.md)
* [RadiationCountermeasuresVSComplete](ValueSet-radiation-countermeasures-vs-complete.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "radiation-countermeasures-cs",
  "url" : "https://mitre.org/fhir/space-health/CodeSystem/radiation-countermeasures-cs",
  "version" : "0.5.10",
  "name" : "RadiationCountermeasuresCS",
  "title" : "Radiation Countermeasures Code System",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-03-12T10:22:25-05:00",
  "publisher" : "MITRE",
  "contact" : [
    {
      "name" : "MITRE",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.mitre.org/"
        }
      ]
    }
  ],
  "description" : "Protective measures against space radiation",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 4,
  "concept" : [
    {
      "code" : "shielding",
      "display" : "Physical Shielding"
    },
    {
      "code" : "shelter",
      "display" : "Radiation Shelter"
    },
    {
      "code" : "medication",
      "display" : "Radioprotective Medication"
    },
    {
      "code" : "monitoring",
      "display" : "Enhanced Monitoring"
    }
  ]
}

```
