# Location - Dragon Capsule - v0.4.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Dragon Capsule**

## Example Location: Location - Dragon Capsule

**name**: Location - Dragon Capsule



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationDragon",
  "name" : "Location - Dragon Capsule"
}

```
