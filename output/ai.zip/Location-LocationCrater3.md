# Location - Habitat Crater - v0.4.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Habitat Crater**

## Example Location: Location - Habitat Crater

**name**: Location - Habitat Crater



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationCrater3",
  "name" : "Location - Habitat Crater"
}

```
