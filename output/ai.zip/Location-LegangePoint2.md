# Location - Legrange Point 2 - v0.4.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Legrange Point 2**

## Example Location: Location - Legrange Point 2

Profile: [xGeo Locations](StructureDefinition-SpaceLocation.md)

**name**: Location - Legrange Point 2



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LegangePoint2",
  "meta" : {
    "profile" : [
      "https://mitre.org/fhir/space-health/StructureDefinition/SpaceLocation"
    ]
  },
  "name" : "Location - Legrange Point 2"
}

```
