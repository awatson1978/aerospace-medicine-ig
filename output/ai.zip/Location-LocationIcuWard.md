# Location - ICU Ward - v0.5.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - ICU Ward**

## Example Location: Location - ICU Ward

**name**: Location - ICU Ward



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationIcuWard",
  "name" : "Location - ICU Ward"
}

```
