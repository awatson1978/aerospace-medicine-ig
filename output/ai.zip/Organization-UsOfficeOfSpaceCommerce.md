# Org - Office of Space Commerce - v0.4.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Org - Office of Space Commerce**

## Example Organization: Org - Office of Space Commerce 

**name**: Office of Space Commerce 



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "UsOfficeOfSpaceCommerce",
  "name" : "Office of Space Commerce "
}

```
