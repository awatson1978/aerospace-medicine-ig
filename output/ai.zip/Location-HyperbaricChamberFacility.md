# Hyperbaric Treatment Chamber - v0.4.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Hyperbaric Treatment Chamber**

## Example Location: Hyperbaric Treatment Chamber

**name**: Hyperbaric Treatment Chamber

**description**: Medical facility for hyperbaric oxygen therapy



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "HyperbaricChamberFacility",
  "name" : "Hyperbaric Treatment Chamber",
  "description" : "Medical facility for hyperbaric oxygen therapy"
}

```
