# Location - ICU Bed - v0.4.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - ICU Bed**

## Example Location: Location - ICU Bed

**name**: Location - ICU Bed



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "LocationIcuBed",
  "name" : "Location - ICU Bed"
}

```
